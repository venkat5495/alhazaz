<!doctype html>
<html class="no-js" lang="zxx">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="meta description">
<!-- Favicons -->
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="assets/img/icon.png">

<!-- Title -->
<title>Welcome to Alfahd Watch</title>

<!-- ************************* CSS Files ************************* -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/elegent-icons.css">
<link rel="stylesheet" href="assets/css/plugins.css">
<link rel="stylesheet" href="assets/css/main.css">

<link id="effect" rel="stylesheet" type="text/css" media="all" href="assets/css/fade-down.css" />
<link rel="stylesheet" type="text/css" media="all" href="assets/css/webslidemenu.css" />
<link id="theme" rel="stylesheet" type="text/css" media="all" href="assets/css/white-gry.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<!-- modernizr JS
============================================ -->
<script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
<!--[if lt IE 9]>
<script src="//oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="//oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>


<!-- Main Wrapper Start -->
<div class="wrapper bg--shaft">
<!-- Main Content Wrapper Start -->
<div class="main-content-wrapper">
    <div class="maintenance-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="site-maintenance">
                        <h2>SITE MAINTENANCE</h2>
                        <h1>Sorry for the inconvenience!</h1>
                        <p>Our site is down for maintenance and will be back soon. Sorry for the inconvenience. In the mean time, you can visit us on our social pages.</p>
                        <figure>
                            <a href="index.html">
                                <img src="assets/img/logo/logo.png" alt="Logo">
                            </a>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Main Content Wrapper Start -->

<!-- Scroll To Top Start -->    
<a class="scroll-to-top" href=""><i class="fa fa-angle-double-up"></i></a>
<!-- Scroll To Top End -->

<!-- Popup Subscribe Box Start -->

<div class="popup-subscribe-box" id="subscribe-popup">
    <div class="popup-subscribe-box-content">
        <div class="popup-subscribe-box-body">
            <a href="#subscribe-popup" class="popup-close">close</a>
            <h3>NEWSLETTER</h3>
            <p>Subscribe to our newsletters now and stay up-to-date with new collections, the latest lookbooks and exclusive offers.</p>
            <form class="popup-subscribe-form validate" action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&id=05d85f18ef" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" target="_blank" novalidate>
                <input type="email" name="popup-subscribe-email" id="popup-subscribe-email" placeholder="Enter your email here...">
                <input type="submit" value="Subscribe" class="btn subscribe-btn btn-medium btn-style-1">
                <div class="form-group text-center mt--20">
                    <input type="checkbox" name="hide-popup" id="hide-popup">
                    <label for="hide-popup"> Don't show this popup again </label>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Popup Subscribe Box End -->

<!-- Modal Start -->
<div class="modal fade product-modal" id="productModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">Close</span>
        </button>
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6 mb-sm--20">
                    <div class="tab-content product-thumb-large">
                        <div id="thumb1" class="tab-pane active show fade">
                            <img src="assets/img/products/1-1-600x600.jpg" alt="product thumb">
                        </div>
                        <div id="thumb2" class="tab-pane fade">
                            <img src="assets/img/products/2-600x600.jpg" alt="product thumb">
                        </div>
                        <div id="thumb3" class="tab-pane fade">
                            <img src="assets/img/products/10-600x600.jpg" alt="product thumb">
                        </div>
                        <div id="thumb4" class="tab-pane fade">
                            <img src="assets/img/products/11-600x600.jpg" alt="product thumb">
                        </div>
                        <div id="thumb5" class="tab-pane fade">
                            <img src="assets/img/products/12-600x600.jpg" alt="product thumb">
                        </div>
                        <div id="thumb6" class="tab-pane fade">
                            <img src="assets/img/products/13-600x600.jpg" alt="product thumb">
                        </div>
                    </div>
                    <div class="product-thumbnail">
                        <div class="thumb-menu" id="modal-thumbmenu">
                            <div class="thumb-menu-item">
                                <a href="#thumb1" data-toggle="tab" class="nav-link active">
                                    <img src="assets/img/products/1-1-450x450.jpg" alt="product thumb">
                                </a>
                            </div>
                            <div class="thumb-menu-item">
                                <a href="#thumb2" data-toggle="tab" class="nav-link">
                                    <img src="assets/img/products/2-2-450x450.jpg" alt="product thumb">
                                </a>
                            </div>
                            <div class="thumb-menu-item">
                                <a href="#thumb3" data-toggle="tab" class="nav-link">
                                    <img src="assets/img/products/10-10-450x450.jpg" alt="product thumb">
                                </a>
                            </div>
                            <div class="thumb-menu-item">
                                <a href="#thumb4" data-toggle="tab" class="nav-link">
                                    <img src="assets/img/products/11-11-450x450.jpg" alt="product thumb">
                                </a>
                            </div>
                            <div class="thumb-menu-item">
                                <a href="#thumb5" data-toggle="tab" class="nav-link">
                                    <img src="assets/img/products/12-12-450x450.jpg" alt="product thumb">
                                </a>
                            </div>
                            <div class="thumb-menu-item">
                                <a href="#thumb6" data-toggle="tab" class="nav-link">
                                    <img src="assets/img/products/13-13-450x450.jpg" alt="product thumb">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 col-md-6">
                    <div class="modal-box product">
                        <h3 class="product-title">Acer Aspire E 15</h3>
                        <div class="ratings mb--20">
                            <i class="fa fa-star rated"></i>
                            <i class="fa fa-star rated"></i>
                            <i class="fa fa-star rated"></i>
                            <i class="fa fa-star rated"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <ul class="product-detail-list list-unstyled mb--20">
                            <li>Brand: <a href="">Apple</a></li>
                            <li>Product Code: Watches</li>
                            <li>Reward Points: 600</li>
                            <li>Availability: In Stock</li>
                        </ul>
                        <div class="product-price border-bottom pb--20 mb--20">
                            <span class="regular-price">$100.50</span>
                            <span class="sale-price">$98.98</span>
                        </div>
                        <div class="product-options mb--20">
                            <h3>Available Options</h3>
                            <div class="form-group">
                                <label><sup>*</sup>Color Switch</label>
                                <select>
                                    <option> --- Please Select --- </option>
                                    <option>Black</option>
                                    <option>Blue</option>
                                </select>
                            </div>
                        </div>
                        <div class="product-action-wrapper mb--20">
                            <div class="product-action-top d-flex align-items-center mb--20">
                                <div class="quantity">
                                    <span>Qty: </span>
                                    <input type="number" class="quantity-input" name="qty" id="qty" value="1" min="1">
                                </div>
                                <button type="button" class="btn btn-medium btn-style-2 add-to-cart">
                                    Add To Cart
                                </button>
                            </div>
                            <div class="product-action-bottom">
                                <a href="wishlist.html">+Add to wishlist</a>
                                <a href="compare.html">+Add to compare</a>
                            </div>
                        </div>  
                        <p class="product-tags">
                            Tags: <a href="shop.html">Sport</a>,
                            <a href="shop.html">Luxury</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Modal End -->

</div>
<!-- Main Wrapper End -->


<!-- ************************* JS Files ************************* --> 
<!-- jQuery JS --> 
<script src="assets/js/vendor/jquery.min.js"></script> 
<!-- Bootstrap and Popper Bundle JS --> 
<script src="assets/js/bootstrap.bundle.min.js"></script> 
<!-- All Plugins Js --> 
<script src="assets/js/plugins.js"></script> 
<!-- Ajax Mail Js --> 
<script src="assets/js/ajax-mail.js"></script> 
<script type="text/javascript" src="assets/css/webslidemenu.js"></script>
<!-- Main JS --> 
<script src="assets/js/main.js"></script>

</body>

</html>