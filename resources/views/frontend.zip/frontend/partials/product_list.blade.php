@foreach ($products as $key => $product)
    <div class="col-lg-4 col-md-4 col-12 ">
        <div class="single_product">
            <div class="product_thumb">
                <a class="primary_img" href="{{ route('product', $product->slug) }}"><img src="{{ asset($product->thumbnail_img) }}" alt=""></a>
                @if(!empty($product->photo))
                    <a class="secondary_img" href="{{ route('product', $product->slug) }}"><img src="{{ asset(json_decode($product->photo[0])) }}" alt=""></a>
                @endif
                <div class="product_action">
                    <div class="hover_action">
                        <a href="#"><i class="fa fa-plus"></i></a>
                        <div class="action_button">
                            <ul>
                                <li><a title="add to cart" href="javascript:void(0)"><i class="fa fa-shopping-basket" onclick="showAddToCartModal({{ $product->id }})" aria-hidden="true"></i></a></li>
                                <li><a href="javascript:void(0)" title="Add to Wishlist" id="add_to_whishlist_{{ $product->id }}" onclick="addToWishList({{ $product->id }})"><i class="{{isset($product->follow) && $product->follow == 1 ? 'fa fa-heart' : 'fa fa-heart-o' }}" aria-hidden="true"></i></a></li>
                                <li><a href="javascript:void(0)" title="Add to Compare" onclick="addToCompare({{ $product->id }})"><i class="fa fa-sliders" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="quick_button">
                    <a href="javascript:void(0)" onclick="showAddToCartModal({{ $product->id }})" title="quick_view">+ quick view</a>
                </div>

                <div class="double_base">
                    {{-- <div class="product_sale">
                        <span>-7%</span>
                    </div> --}}
                    @if (strtotime($product->created_at) > strtotime('-10 day'))
                        <div class="label_product">
                            <span>{{__('New')}}</span>
                        </div>
                    @endif
                </div>
            </div>

            <div class="product_content grid_content">
                <h3>
                    <a href="{{ route('product', $product->slug) }}">{{ __($product->name) }}</a>
                </h3>
                <span class="current_price">{{ home_discounted_base_price($product) }}</span>
                @if(home_base_price($product) != home_discounted_base_price($product))
                    <span class="old_price">{{ home_base_price($product) }}</span>
                @endif
            </div>


            <div class="product_content list_content">
                <h3>
                    <a href="{{ route('product', $product->slug) }}">{{ __($product->name) }}</a>
                </h3>
                <div class="product_ratting">
                    <ul>
                        @for ($i=0; $i < floor($product->avg_rating); $i++)
                            <li><i class="fa fa-star"></i></li>
                        @endfor
                        @for ($i=0; $i < ceil(5-$product->avg_rating); $i++)
                            <li><i class="fa fa-star-o"></i></li>
                        @endfor

                    </ul>
                </div>
                <div class="product_price">
                    <span class="current_price">{{ home_discounted_base_price($product) }}</span>
                    @if(home_base_price($product) != home_discounted_base_price($product))
                        <span class="old_price">{{ home_base_price($product) }}</span>
                    @endif
                </div>
                <div class="product_desc">
                    {!! $product->description !!}
                </div>

            </div>

        </div>
    </div>
@endforeach
@if($products->hasMorePages())
    <a class="next_page_url" href="{{ $products->nextPageUrl() }}"></a>
@endif
