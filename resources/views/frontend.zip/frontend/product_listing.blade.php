@extends('frontend.layouts.app')
@section('content')
    @php
    if(\App\Language::where('code', Session::get('locale', Config::get('app.locale')))->first()->rtl == 1)
    {
        $current_language="arabic";
        $page_title = "متجر";
    } else {
        $current_language="english";
        $page_title = "Shop";
    }
    $brands = array();
    @endphp
    @if(isset($subsubcategory_id))
        @php
            foreach (json_decode(\App\SubSubCategory::find($subsubcategory_id)->brands) as $brand) {
                if(!in_array($brand, $brands)){
                    array_push($brands, $brand);
                }
            }
        @endphp
    @elseif(isset($subcategory_id))
        @foreach (\App\SubCategory::find($subcategory_id)->subsubcategories as $key => $subsubcategory)
            @php
                foreach (json_decode($subsubcategory->brands) as $brand) {
                    if(!in_array($brand, $brands)){
                        array_push($brands, $brand);
                    }
                }
            @endphp
        @endforeach
    @elseif(isset($category_id))
        @foreach (\App\Category::find($category_id)->subcategories as $key => $subcategory)
            @foreach ($subcategory->subsubcategories as $key => $subsubcategory)
                @php
                    foreach (json_decode($subsubcategory->brands) as $brand) {
                        if(!in_array($brand, $brands)){
                            array_push($brands, $brand);
                        }
                    }
                @endphp
            @endforeach
        @endforeach
    @else
        @php
            foreach (\App\Brand::all() as $key => $brand){
                if(!in_array($brand->id, $brands)){
                    array_push($brands, $brand->id);
                }
            }
        @endphp
    @endif
<!-- Breadcumb area Start -->
<div class="breadcrumb-area">
<div class="container">
    <div class="row">
        <div class="col-12 text-center">
            <h1 class="page-title"><?= $page_title ?></h1>
            <ul class="breadcrumb justify-content-center">
                <li><a href="#">Home</a></li>
                <li class="current"><a href="shop-list.html">Shop List</a></li>
            </ul>
        </div>
    </div>
</div>
</div>
<!-- Breadcumb area End -->

<!-- Main Content Wrapper Start -->
<div class="main-content-wrapper">
<div class="shop-area pt--40 pb--80 pt-md--30 pb-md--60">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-12">
                        <!-- Refine Search Start -->
                        <!--<div class="refine-search mb--30">
                            <h3>Refine Search</h3>
                            <ul class="cat-list mb--20">
                                <li><a href="shop.html">Diamonds (3)</a></li>
                                <li><a href="shop.html">For Mens's (15)</a></li>
                                <li><a href="shop.html">For Womens's (16)</a></li>
                                <li><a href="shop.html">Jewlery (3)</a></li>
                                <li><a href="shop.html">Watches (13)</a></li>
                            </ul>
                            <ul class="cat-list">
                                <li><a href="shop.html">Product Compare (3)</a></li>
                            </ul>
                        </div>-->
                        <!-- Refine Search End -->

                        <!-- Shop Toolbar Start -->
                        <div class="shop-toolbar">
                            <div class="product-view-mode" data-default="list">
                                <a class="grid-2" data-target="gridview-2" data-toggle="tooltip" data-placement="top" title="2">2</a>
                                <a class="grid-3" data-target="gridview-3" data-toggle="tooltip" data-placement="top" title="3">3</a>
                                <a class="grid-4 active" data-target="gridview-4" data-toggle="tooltip" data-placement="top" title="4">4</a>
                                <a class="grid-5" data-target="gridview-5" data-toggle="tooltip" data-placement="top" title="5">5</a>
                                <a class="list" data-target="listview" data-toggle="tooltip" data-placement="top" title="5">List</a>
                            </div>
                            <span class="product-pages"><p>Showing  {{($products->currentpage()-1)*$products->perpage()+1}} - {{$products->currentpage()*$products->perpage()}} of  {{$products->total()}} results</p></span>
                            <form class="select_option" id="search-form">
                                <input type="hidden" name="q" value="{{ isset($_GET['q']) ? $_GET['q'] : '' }}">
                                <div class="product-short">
                                    <label class="select-label">Sort By:</label>
                                    <select class="select_option short-select nice-select" name="orderby" id="sort">
                                        <option disabled="">{{__('Sort By')}}</option>
                                        <option value="1" {{isset ($sort_by) && $sort_by ==1 ? 'selected' : '' }}>Newness</option>
                                        <option value="2" {{isset ($sort_by) && $sort_by ==2 ? 'selected' : '' }}>Oldest</option>
                                        <option value="3" {{isset ($sort_by) && $sort_by ==3 ? 'selected' : '' }}>Price: low to high</option>
                                        <option value="4" {{isset ($sort_by) && $sort_by ==4 ? 'selected' : '' }}>Price: high to low</option>
                                    </select>
                                </div>
                            </form>
                        </div>
                        <!-- Shop Toolbar End -->
                    </div>
                </div>
                
                <!-- Main Shop wrapper Start -->
                @if(count($products) > 0)
                <div class="shop-product-wrap gridview-4 row no-gutters">
                    
                    @foreach ($products as $key => $product)
                        <?php $brand = (\App\Brand::whereid($product->brand_id)->first()); ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                            @include('frontend.single_product')
                        </div>
                    @endforeach
                </div>
                @else
                    <div class="shop-product-wrap gridview-4 row no-gutters"><p>{{__('No items found.')}}</p></div>
                @endif
                <!-- Main Shop wrapper End -->

                <!-- Pagination Start 
                <div class="pagination-wrap mt--15 mt-md--10">
                    <p class="page-ammount">Showing 1 to 9 of 15 (2 Pages)</p>
                    <ul class="pagination">
                        <li><a href="" class="first">|&lt;</a></li>
                        <li><a href="" class="prev">&lt;</a></li>
                        <li><a href="" class="current">1</a></li>
                        <li><a href="">2</a></li>
                        <li><a href="" class="next">&gt;</a></li>
                        <li><a href="" class="next">&gt;|</a></li>
                    </ul>
                </div>-->
                <!-- Pagination End -->
            </div>
        </div>
    </div>
</div>
</div>
<!-- Main Content Wrapper Start -->
@endsection
